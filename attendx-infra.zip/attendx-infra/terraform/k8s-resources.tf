############################################################
# Namespace
############################################################

resource "kubernetes_namespace" "app" {
  metadata {
    name = var.k8s_namespace
  }

  depends_on = [module.eks]
}

############################################################
# DB credentials Secret
#
# Spring Boot reads DB_URL / DB_USERNAME / DB_PASSWORD from the
# environment (see application.properties). This Secret is the
# "wire" connecting the RDS instance created above to the backend
# Deployment in k8s/10-backend-deployment.yaml (via envFrom).
############################################################

resource "kubernetes_secret" "db_credentials" {
  metadata {
    name      = "db-credentials"
    namespace = kubernetes_namespace.app.metadata[0].name
  }

  data = {
    DB_URL      = "jdbc:mariadb://${aws_db_instance.mariadb.address}:3306/${var.db_name}"
    DB_USERNAME = var.db_username
    DB_PASSWORD = random_password.db_password.result
  }

  type = "Opaque"
}

############################################################
# Non-secret app config
############################################################

resource "kubernetes_config_map" "app_config" {
  metadata {
    name      = "attendx-config"
    namespace = kubernetes_namespace.app.metadata[0].name
  }

  data = {
    SERVER_PORT = "8080"
    DDL_AUTO    = "update"
  }
}
