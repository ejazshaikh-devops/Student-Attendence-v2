############################################
# General
############################################

variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "ap-south-1"
}

variable "project_name" {
  description = "Short name used to prefix/tag all resources"
  type        = string
  default     = "attendx"
}

variable "environment" {
  description = "Environment name (dev / staging / prod)"
  type        = string
  default     = "dev"
}

############################################
# Networking
############################################

variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "az_count" {
  description = "Number of Availability Zones to spread subnets across"
  type        = number
  default     = 2
}

############################################
# EKS
############################################

variable "cluster_version" {
  description = "Kubernetes version for the EKS control plane"
  type        = string
  default     = "1.30"
}

variable "node_instance_types" {
  description = "Instance types for the EKS managed node group"
  type        = list(string)
  default     = ["t3.medium"]
}

variable "node_desired_size" {
  description = "Desired number of worker nodes"
  type        = number
  default     = 2
}

variable "node_min_size" {
  description = "Minimum number of worker nodes"
  type        = number
  default     = 2
}

variable "node_max_size" {
  description = "Maximum number of worker nodes"
  type        = number
  default     = 4
}

variable "k8s_namespace" {
  description = "Kubernetes namespace the app is deployed into"
  type        = string
  default     = "attendx"
}

variable "additional_eks_admin_arns" {
  description = "Extra IAM principal ARNs (e.g. your Jenkins agent's role) granted cluster-admin via EKS access entries, e.g. [\"arn:aws:iam::123456789012:role/jenkins-eks-deploy\"]"
  type        = list(string)
  default     = []
}

############################################
# RDS (MariaDB)
############################################

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "db_engine_version" {
  description = "MariaDB engine version (must match what the app/driver expects)"
  type        = string
  default     = "10.11"
}

variable "db_allocated_storage" {
  description = "Allocated storage for RDS in GB"
  type        = number
  default     = 20
}

variable "db_name" {
  description = "Initial database name (matches application.properties)"
  type        = string
  default     = "attendance"
}

variable "db_username" {
  description = "Master username for the RDS instance"
  type        = string
  default     = "attendx"
}

variable "db_multi_az" {
  description = "Whether to enable Multi-AZ for RDS (cost vs HA tradeoff)"
  type        = bool
  default     = false
}

variable "db_skip_final_snapshot" {
  description = "Skip final snapshot on destroy (set false for real prod)"
  type        = bool
  default     = true
}
