terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.50"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.30"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.13"
    }
    random = {
      source  = "hashicorp/random"
      version = "~> 3.6"
    }
  }

  # ---------------------------------------------------------------
  # Recommended: store state remotely so it isn't lost / can be
  # shared with Jenkins. Create the S3 bucket + DynamoDB lock table
  # once (manually or in a tiny bootstrap stack), then uncomment:
  # ---------------------------------------------------------------
  # backend "s3" {
  #   bucket         = "attendx-terraform-state"
  #   key            = "attendx/terraform.tfstate"
  #   region         = "ap-south-1"
  #   dynamodb_table = "attendx-terraform-locks"
  #   encrypt        = true
  # }
}
