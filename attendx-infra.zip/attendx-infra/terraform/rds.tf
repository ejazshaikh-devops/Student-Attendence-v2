############################################################
# RDS - managed MariaDB
#
# Lives in the private subnets, reachable only from the EKS
# node security group on port 3306.
############################################################

resource "random_password" "db_password" {
  length  = 20
  special = false # avoid chars that need URL/JDBC escaping in connection strings
}

resource "aws_db_subnet_group" "this" {
  name       = "${local.cluster_name}-db-subnets"
  subnet_ids = module.vpc.private_subnets

  tags = {
    Name = "${local.cluster_name}-db-subnets"
  }
}

resource "aws_security_group" "rds" {
  name        = "${local.cluster_name}-rds-sg"
  description = "Allow MariaDB access from EKS worker nodes"
  vpc_id      = module.vpc.vpc_id

  ingress {
    description     = "MariaDB from EKS nodes"
    from_port        = 3306
    to_port          = 3306
    protocol         = "tcp"
    security_groups  = [module.eks.node_security_group_id]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name = "${local.cluster_name}-rds-sg"
  }
}

resource "aws_db_instance" "mariadb" {
  identifier     = "${local.cluster_name}-db"
  engine         = "mariadb"
  engine_version = var.db_engine_version

  instance_class    = var.db_instance_class
  allocated_storage = var.db_allocated_storage
  storage_type      = "gp3"
  storage_encrypted = true

  db_name  = var.db_name
  username = var.db_username
  password = random_password.db_password.result
  port     = 3306

  db_subnet_group_name   = aws_db_subnet_group.this.name
  vpc_security_group_ids = [aws_security_group.rds.id]

  multi_az            = var.db_multi_az
  publicly_accessible = false

  backup_retention_period = 7
  skip_final_snapshot     = var.db_skip_final_snapshot
  deletion_protection     = false

  tags = {
    Name = "${local.cluster_name}-db"
  }
}
