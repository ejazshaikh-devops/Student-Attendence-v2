output "aws_region" {
  value = var.aws_region
}

output "cluster_name" {
  description = "EKS cluster name"
  value       = module.eks.cluster_name
}

output "configure_kubectl" {
  description = "Run this to point kubectl/Jenkins at the new cluster"
  value       = "aws eks update-kubeconfig --region ${var.aws_region} --name ${module.eks.cluster_name}"
}

output "vpc_id" {
  value = module.vpc.vpc_id
}

output "ecr_backend_repository_url" {
  description = "Push backend images here"
  value       = aws_ecr_repository.backend.repository_url
}

output "ecr_frontend_repository_url" {
  description = "Push frontend images here"
  value       = aws_ecr_repository.frontend.repository_url
}

output "rds_endpoint" {
  description = "RDS host (no port)"
  value       = aws_db_instance.mariadb.address
}

output "rds_jdbc_url" {
  description = "Full JDBC URL stored in the db-credentials Secret"
  value       = "jdbc:mariadb://${aws_db_instance.mariadb.address}:3306/${var.db_name}"
}

output "db_username" {
  value = var.db_username
}

output "db_password" {
  value     = random_password.db_password.result
  sensitive = true
}

output "k8s_namespace" {
  value = kubernetes_namespace.app.metadata[0].name
}
