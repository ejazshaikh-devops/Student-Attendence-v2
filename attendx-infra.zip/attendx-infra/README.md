# AttendX — AWS Infra (Terraform + EKS + RDS + Docker + K8s + HPA + Ingress)

This package provisions everything below your existing `backend/` and
`frontend/attendance-frontend/` apps so they run on AWS without any
`localhost` assumptions. **Your Dockerfiles and `application.properties`
are already correct as-is** — nothing in them needs to change. This infra
just supplies the right environment variables and networking.

```
AttendanceApp/                <- your existing repo
├── backend/                   (unchanged)
├── frontend/attendance-frontend/  (unchanged)
└── attendx-infra/             <- this package, drop it into the repo root
    ├── terraform/             AWS: VPC, EKS, RDS, ECR, IAM/IRSA, addons
    ├── k8s/                   Deployments, Services, HPA, Ingress
    └── scripts/build-and-push.sh
```

## Architecture

```
                                Internet
                                   │
                          ┌────────▼─────────┐
                          │   ALB (Ingress)   │  <- AWS Load Balancer Controller
                          └────────┬─────────┘
                                   │  :80
                          ┌────────▼─────────┐
                          │ frontend Service │  (ClusterIP)
                          │  nginx, 2-4 pods │  <- HPA
                          └────────┬─────────┘
                            /         \
                  static React files   /api/* → proxy_pass
                                          │
                          ┌───────────────▼──┐
                          │  backend Service  │ (ClusterIP, name "backend")
                          │ Spring Boot 2-6   │ <- HPA
                          │      pods         │
                          └───────────────┬──┘
                                           │ JDBC :3306
                                  ┌────────▼────────┐
                                  │   RDS MariaDB    │ (private subnets)
                                  └─────────────────┘

  EKS worker nodes + RDS live in private subnets.
  Only the ALB is internet-facing.
```

Everything runs in the `attendx` namespace, in EKS managed node groups,
in a dedicated VPC with public + private subnets across 2 AZs.

---

## Prerequisites (on your machine / Jenkins agent)

- AWS CLI v2, configured (`aws configure` or SSO) with an account that can
  create VPC/EKS/RDS/IAM/ECR resources
- Terraform >= 1.5
- `kubectl`
- Docker

> Helm itself doesn't need to be installed — Terraform's `helm` provider
> installs the AWS Load Balancer Controller and `metrics-server` for you.

---

## 1. Provision everything with Terraform

```bash
cd attendx-infra/terraform
cp terraform.tfvars.example terraform.tfvars
# edit terraform.tfvars if you want to change region/sizes/etc.

terraform init
terraform apply
```

This single apply creates:

- **VPC** — 2 public + 2 private subnets, 1 NAT gateway, tagged for the
  AWS Load Balancer Controller's auto-discovery
- **EKS cluster** + managed node group (2–4 × `t3.medium`)
- **RDS MariaDB** (`db.t3.micro`, 20GB, private subnets only, reachable
  only from EKS nodes on port 3306)
- **ECR repos** for `attendx-backend` and `attendx-frontend`
- **AWS Load Balancer Controller** (via Helm, IRSA) — powers the Ingress
- **metrics-server** (via Helm) — required for HPA to function
- A Kubernetes **namespace** (`attendx`), a **Secret** `db-credentials`
  (DB_URL/DB_USERNAME/DB_PASSWORD pointing at the new RDS instance), and
  a **ConfigMap** `attendx-config`

Takes ~15-20 minutes (EKS cluster creation is the slow part).

When it's done:

```bash
terraform output                 # see ECR URLs, RDS endpoint, etc.
$(terraform output -raw configure_kubectl)   # points kubectl at the new cluster
```

---

## 2. Build & push images (no Dockerfile changes needed)

From the **repo root**:

```bash
./attendx-infra/scripts/build-and-push.sh v1
```

This builds `backend/Dockerfile` and
`frontend/attendance-frontend/Dockerfile` exactly as they are, and pushes
to the two ECR repos Terraform just created.

---

## 3. Point the k8s manifests at your images and deploy

```bash
cd attendx-infra
BACKEND_REPO=$(cd terraform && terraform output -raw ecr_backend_repository_url)
FRONTEND_REPO=$(cd terraform && terraform output -raw ecr_frontend_repository_url)

sed -i "s#<ECR_BACKEND_REPO_URL>#${BACKEND_REPO}#"   k8s/10-backend-deployment.yaml
sed -i "s#<ECR_FRONTEND_REPO_URL>#${FRONTEND_REPO}#" k8s/20-frontend-deployment.yaml
# also set the :latest tag to :v1 (or whatever tag you pushed) if not using latest

kubectl apply -f k8s/
```

Check rollout:

```bash
kubectl get pods -n attendx
kubectl get hpa -n attendx
kubectl get ingress -n attendx -w   # wait for ADDRESS (ALB DNS name) to appear, ~2-3 min
```

Open the ALB's DNS name in your browser — that's your app, same UI as
`localhost`, now talking to RDS.

---

## How the DB connection is actually wired (fixes the "localhost" issue)

Your `application.properties` already does the right thing:

```properties
spring.datasource.url=${DB_URL:jdbc:mariadb://localhost:3306/attendance}
spring.datasource.username=${DB_USERNAME: }
spring.datasource.password=${DB_PASSWORD: }
```

It falls back to `localhost` **only if `DB_URL` isn't set**. In this infra,
Terraform creates a Secret `db-credentials` from the real RDS instance:

```
DB_URL      = jdbc:mariadb://<rds-endpoint>:3306/attendance
DB_USERNAME = attendx
DB_PASSWORD = <random, generated by terraform>
```

`k8s/10-backend-deployment.yaml` injects that Secret with `envFrom`, so the
Spring Boot pod sees `DB_URL`/`DB_USERNAME`/`DB_PASSWORD` as real
environment variables and connects to RDS — never to `localhost`.

To see the actual generated password later: `terraform output db_password`
(or `terraform output -raw db_password`).

---

## Troubleshooting: "DB connects but data isn't being saved"

This usually isn't a code bug — the controllers/repositories look correct.
Most likely causes, in order of likelihood:

1. **Tables were never created** — `spring.jpa.hibernate.ddl-auto` must be
   `update` (it is, via the `attendx-config` ConfigMap → `DDL_AUTO=update`).
   Confirm on first boot:
   ```bash
   kubectl logs -n attendx deploy/backend | grep -i hibernate
   ```
   You should see `Hibernate: create table ...` on the very first startup.

2. **Check the tables actually exist in RDS.** Run a throwaway pod with a
   MariaDB client inside the cluster (it can reach RDS, your laptop can't
   since RDS is private):
   ```bash
   kubectl run -n attendx mysql-client --rm -it --restart=Never \
     --image=mariadb:10.11 -- \
     mariadb -h $(terraform -chdir=terraform output -raw rds_endpoint) \
             -u attendx -p"$(terraform -chdir=terraform output -raw db_password)" attendance \
             -e "SHOW TABLES; SELECT * FROM student; SELECT * FROM attendance;"
   ```

3. **Requests aren't reaching the backend at all.** Open browser dev tools
   → Network tab while adding a student. If POST `/api/students` returns
   a CORS error or 404/502:
   - `CorsConfig.java` only allow-lists `http://localhost:5173,3000` — but
     in this setup the browser talks to **nginx (same origin)**, and nginx
     proxies `/api/` → `http://backend:8080/` internally, so CORS doesn't
     come into play. If you *do* see a CORS error, you're hitting the
     backend Service/pod directly instead of going through the frontend/ALB.
   - A 502/504 from `/api/...` means the `backend` Service has no ready
     pods yet — check `kubectl get pods -n attendx` and
     `kubectl logs -n attendx deploy/backend`.

4. **"It saves, but a refresh shows nothing"** — usually a second tab/window
   still pointed at an old/local backend, or the browser cached an old
   build of the frontend. Hard-refresh, and confirm the page is loading
   from the ALB DNS name, not `localhost`.

5. **RDS user permission issue** — shouldn't happen here since the RDS
   master user (`attendx`) has full privileges on the `attendance`
   database by default, but if you ever switch to a non-master user,
   make sure it has `CREATE, ALTER, INSERT, SELECT, UPDATE, DELETE` on
   `attendance.*`.

---

## HPA notes

- Both Deployments set CPU/memory `requests` (required for HPA math) and
  have HPAs (`12-backend-hpa.yaml`, `22-frontend-hpa.yaml`) targeting 70%
  CPU.
- `metrics-server` is installed by Terraform — without it `kubectl get hpa`
  shows `<unknown>` for targets forever.
- Quick load test:
  ```bash
  kubectl run -n attendx load --image=busybox --restart=Never -- \
    /bin/sh -c "while true; do wget -q -O- http://backend:8080/students; done"
  kubectl get hpa -n attendx -w
  ```

---

## Wiring up Jenkins later

When you build the Jenkins pipeline, it'll need to:

1. **Build & push images** to the two ECR repos
   (`terraform output ecr_backend_repository_url` /
   `..._frontend_repository_url`). The Jenkins IAM identity needs an ECR
   push policy:
   ```json
   {
     "Effect": "Allow",
     "Action": [
       "ecr:GetAuthorizationToken",
       "ecr:BatchCheckLayerAvailability",
       "ecr:GetDownloadUrlForLayer",
       "ecr:BatchGetImage",
       "ecr:PutImage",
       "ecr:InitiateLayerUpload",
       "ecr:UploadLayerPart",
       "ecr:CompleteLayerUpload"
     ],
     "Resource": "*"
   }
   ```

2. **Deploy to EKS** — `kubectl set image` or `kubectl apply -f k8s/`
   (after templating the image tags, e.g. with `sed` like in step 3 above,
   or switch `k8s/` to a Kustomize overlay). Jenkins' IAM
   role/user needs cluster access: add its ARN to
   `additional_eks_admin_arns` in `terraform.tfvars` and re-apply — this
   grants it an EKS access entry with cluster-admin.

3. Typical stages: `checkout` → `build & test` (mvn / npm) →
   `docker build & push` (both images) → `kubectl apply -f k8s/` →
   `rollout status` smoke check.

---

## Cleanup

```bash
kubectl delete -f attendx-infra/k8s/      # drop the ALB first (avoids orphaned LB)
cd attendx-infra/terraform
terraform destroy
```

`db_skip_final_snapshot = true` (default) means RDS is destroyed without a
final snapshot — set it to `false` in `terraform.tfvars` if you care about
the data.
