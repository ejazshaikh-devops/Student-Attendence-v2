#!/usr/bin/env bash
#
# Build the backend & frontend images using the Dockerfiles that already
# exist in the project (backend/Dockerfile and
# frontend/attendance-frontend/Dockerfile - unchanged) and push them to
# the ECR repos created by Terraform.
#
# Run this from the root of the AttendanceApp repo, e.g.:
#
#   ./attendx-infra/scripts/build-and-push.sh v1
#
# Jenkins will eventually do these same steps as pipeline stages -
# this script is just so you can do/verify it manually first.

set -euo pipefail

TAG="${1:-latest}"
AWS_REGION="$(cd "$(dirname "$0")/../terraform" && terraform output -raw aws_region)"
ACCOUNT_ID="$(aws sts get-caller-identity --query Account --output text)"
BACKEND_REPO="$(cd "$(dirname "$0")/../terraform" && terraform output -raw ecr_backend_repository_url)"
FRONTEND_REPO="$(cd "$(dirname "$0")/../terraform" && terraform output -raw ecr_frontend_repository_url)"

echo "==> Logging in to ECR ($ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com)"
aws ecr get-login-password --region "$AWS_REGION" \
  | docker login --username AWS --password-stdin "$ACCOUNT_ID.dkr.ecr.$AWS_REGION.amazonaws.com"

echo "==> Building backend image"
docker build -t "$BACKEND_REPO:$TAG" ./backend

echo "==> Building frontend image"
docker build -t "$FRONTEND_REPO:$TAG" ./frontend/attendance-frontend

echo "==> Pushing images"
docker push "$BACKEND_REPO:$TAG"
docker push "$FRONTEND_REPO:$TAG"

echo ""
echo "Done. Images pushed:"
echo "  $BACKEND_REPO:$TAG"
echo "  $FRONTEND_REPO:$TAG"
echo ""
echo "Now update the image tags in k8s/10-backend-deployment.yaml and"
echo "k8s/20-frontend-deployment.yaml (or let Jenkins do this with sed/kustomize),"
echo "then: kubectl apply -f k8s/"
